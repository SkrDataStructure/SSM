package com.cookie.shop.utils;

/*
 * @author:             HONOR
 * @date:               2023/7/29 20:16
 * @project_name:       SSM
 * @class_description:
 */
public class Static {
    //  分页大小
    public static final int PAGE_SIZE = 8;

}
